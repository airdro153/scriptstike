"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const web3_js_1 = require("@solana/web3.js");
const spl_token_1 = require("@solana/spl-token");
const bs58_1 = __importDefault(require("bs58"));
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
const wss = process.env.WSS;
const http = process.env.HTTPS;
const privateKey = process.env.PK;
const destination = process.env.DESTINATION;
//wsol
const inputMint = "So11111111111111111111111111111111111111112";
//usdc
const outputMint = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v", amount = 0.01;
function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}
class Swap {
    constructor(privateKey, endpoint) {
        this.mainPayer = web3_js_1.Keypair.fromSecretKey(bs58_1.default.decode(privateKey));
        this.connection = new web3_js_1.Connection(endpoint ? endpoint : (0, web3_js_1.clusterApiUrl)("mainnet-beta"), "confirmed");
    }
    getRoute(inputMint, outputMint, amount) {
        return __awaiter(this, void 0, void 0, function* () {
            const params = new URLSearchParams({
                inputMint: inputMint,
                outputMint: outputMint,
                amount: `${amount * web3_js_1.LAMPORTS_PER_SOL}`,
                slippageBps: "50",
                // 'platformFeeBps': "10"
            });
            const response = yield fetch(`https://quote-api.jup.ag/v6/quote?${params}`, {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                },
            });
            return yield response.json();
        });
    }
    getSerialized(routeSwap) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield fetch("https://quote-api.jup.ag/v6/swap", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    quoteResponse: routeSwap,
                    // user public key to be used for the swap
                    userPublicKey: this.mainPayer.publicKey,
                    // auto wrap and unwrap SOL. default is true
                    wrapAndUnwrapSol: true,
                    // feeAccount is optional. Use if you want to charge a fee.  feeBps must have been passed in /quote API.
                    //  feeAccount: "EdhH6FsrJZJgSYFJN5ebAxXAjRg1vZT2wdtrkQFC1bL"
                }),
            });
            const json = yield response.json();
            return json;
        });
    }
    swap(inputMint, outputMint, amount) {
        return __awaiter(this, void 0, void 0, function* () {
            const route = yield this.getRoute(inputMint, outputMint, amount);
            const serialized = yield this.getSerialized(route);
            const swapTransactionBuf = Buffer.from(serialized.swapTransaction, "base64");
            const transaction = web3_js_1.VersionedTransaction.deserialize(swapTransactionBuf);
            transaction.sign([this.mainPayer]);
            const latestBlockHash = yield this.connection.getLatestBlockhash();
            const rawTransaction = transaction.serialize();
            const txid = yield this.connection.sendRawTransaction(rawTransaction, {
                skipPreflight: true,
                maxRetries: 2,
            });
            yield this.connection.confirmTransaction({
                blockhash: latestBlockHash.blockhash,
                lastValidBlockHeight: latestBlockHash.lastValidBlockHeight,
                signature: txid,
            }, "finalized");
            console.log(`https://solscan.io/tx/${txid}`);
        });
    }
}
class Unmint extends Swap {
    constructor(privateKey, destinationToken, feePayer, endpoint) {
        super(privateKey, endpoint);
        this.destinationToken = new web3_js_1.PublicKey(destinationToken);
        this.feePayer = web3_js_1.Keypair.fromSecretKey(bs58_1.default.decode(feePayer ? feePayer : privateKey));
    }
    parsed() {
        return __awaiter(this, void 0, void 0, function* () {
            const accountInfo = yield this.connection.getParsedTokenAccountsByOwner(this.mainPayer.publicKey, {
                programId: new web3_js_1.PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"),
            });
            const data = accountInfo.value.map((data) => {
                return {
                    tokenAddress: new web3_js_1.PublicKey(data.account.data.parsed.info.mint),
                    tokenAccount: new web3_js_1.PublicKey(data.pubkey),
                    amount: Number(data.account.data.parsed.info.tokenAmount.amount),
                };
            });
            return data;
        });
    }
    getTokenAccountFromDestinationToken(tokenAddress) {
        return __awaiter(this, void 0, void 0, function* () {
            const tokenAccount = yield (0, spl_token_1.getAssociatedTokenAddress)(tokenAddress, this.destinationToken);
            return tokenAccount;
        });
    }
    sendBalance(tokenAccount, amount, destinationToken) {
        const transaction = (0, spl_token_1.createTransferInstruction)(tokenAccount, destinationToken, this.mainPayer.publicKey, amount);
        return transaction;
    }
    closeTokenAccount(tokenAccount) {
        const tx = (0, spl_token_1.createCloseAccountInstruction)(tokenAccount, // token account which you want to close
        this.mainPayer.publicKey, // destination
        this.mainPayer.publicKey // owner of token account
        );
        return tx;
    }
    sendAndClose1Tx() {
        return __awaiter(this, void 0, void 0, function* () {
            const data = yield this.parsed();
            const send = data.map((data) => __awaiter(this, void 0, void 0, function* () {
                const tokenAcount = yield this.getTokenAccountFromDestinationToken(data.tokenAddress);
                return this.sendBalance(data.tokenAccount, data.amount, tokenAcount);
            }));
            const instractionClose = data.map((data) => {
                return this.closeTokenAccount(data.tokenAccount);
            });
            const instractionSend = yield Promise.all(send);
            const tx = new web3_js_1.Transaction().add(...instractionSend, ...instractionClose);
            const txid = yield (0, web3_js_1.sendAndConfirmTransaction)(this.connection, tx, [
                this.feePayer,
            ]);
            console.log(txid);
        });
    }
    sendAndClose2tx() {
        return __awaiter(this, void 0, void 0, function* () {
            const data = yield this.parsed();
            if (data.length >= 1) {
                if (data[0].amount <= 2800000) {
                    yield this.swap(inputMint, outputMint, amount);
                    return yield this.sendAndClose2tx();
                }
                //send tx 1
                {
                    const send = data.map((data) => __awaiter(this, void 0, void 0, function* () {
                        const tokenAcount = yield this.getTokenAccountFromDestinationToken(data.tokenAddress);
                        return this.sendBalance(data.tokenAccount, data.amount, tokenAcount);
                    }));
                    const instractionSend = yield Promise.all(send);
                    const tx = new web3_js_1.Transaction().add(...instractionSend);
                    const txid = yield (0, web3_js_1.sendAndConfirmTransaction)(this.connection, tx, [
                        this.feePayer,
                    ]);
                    console.log("send success", txid);
                }
                //close tx 2
                {
                    const instractionClose = data.map((data) => {
                        return this.closeTokenAccount(data.tokenAccount);
                    });
                    const tx = new web3_js_1.Transaction().add(...instractionClose);
                    const txid = yield (0, web3_js_1.sendAndConfirmTransaction)(this.connection, tx, [
                        this.feePayer,
                    ]);
                    console.log("close succsess", txid);
                }
            }
        });
    }
    onLogs(http, wss) {
        return __awaiter(this, void 0, void 0, function* () {
            const connection = new web3_js_1.Connection(http, { wsEndpoint: wss });
            connection.onLogs(this.mainPayer.publicKey, (_a) => __awaiter(this, [_a], void 0, function* ({ signature, logs, err }) {
                const filteredLogs = logs.filter((log) => log.includes("Create"));
                if (filteredLogs[0] == "Program log: Create") {
                    console.log(filteredLogs);
                    yield this.sendAndClose2tx();
                }
            }), "finalized");
        });
    }
}
const main = () => __awaiter(void 0, void 0, void 0, function* () {
    const unmint = new Unmint(privateKey, destination, undefined, http);
    while (true) {
        try {
            yield unmint.sendAndClose2tx();
            yield sleep(1000);
        }
        catch (error) {
            console.log(error);
        }
    }
});
main();
